import 'dart:async';

import 'package:equatable/equatable.dart';
import 'package:el_race/ui/presentation/Attendace_list/repository/attendance_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';

part 'home_event.dart';
part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  
  static HomeBloc get(BuildContext context) => BlocProvider.of(context);
  
  HomeBloc() : super(HomeInitial()) {
    on<CheckInStatusChangedEvent>(checkedInMethod);
    on<FetchLastMonthAttendanceSummary>(_fetchLastMonthAttendanceSummary  );      
    on<ChangeCurrentIndex>((event,emit){
      changeCurrentIndex(event, emit);
    });
    on<ChangeVisiablityIcon>((event,emit){
      changeBottomNavVisiblity(event, emit);
    });
    on<UpdateFaceRecognitionStatus>((event, emit) {
      faceRecognitionStatus = event.status;
      emit(FaceRecognitionStatusChanged(event.status));
    });
  
  }

  int currentIndex = 1;
  changeCurrentIndex(ChangeCurrentIndex event,emit){
    emit(ChangeIndexLoading());
    currentIndex = event.index;
    emit(ChangeIndexSuccess());
  }

  bool enableBottomNav = true;
  changeBottomNavVisiblity(ChangeVisiablityIcon event,emit){
    emit(ChangeIndexLoading());
    enableBottomNav = !enableBottomNav;
    emit(ChangeIndexSuccess());
  }

  FutureOr<void> checkedInMethod(CheckInStatusChangedEvent event, Emitter<HomeState> emit) {
    emit(CheckedInSTHome());
  }

  int attendedDays = 0;
  FaceRecognitionStatus faceRecognitionStatus = FaceRecognitionStatus.idle;

  Future<void> _fetchLastMonthAttendanceSummary(
    FetchLastMonthAttendanceSummary event,
    Emitter<HomeState> emit,
  ) async {
    try {
      emit(const LastMonthAttendanceSummaryLoading());
      final now = DateTime.now();
      final firstDayOfLastMonth = DateTime(now.year, now.month , 1);
      final lastDayOfLastMonth = DateTime(now.year, now.month+1, 0);

      final summary = await AttendanceRepo().getAttendanceSummary(
        startDate: DateFormat('yyyy-MM-dd').format(firstDayOfLastMonth),
        endDate: DateFormat('yyyy-MM-dd').format(lastDayOfLastMonth),
      );
      attendedDays = summary['working_days'] ?? 0;
      emit(const LastMonthAttendanceSummaryLoaded());
      // No emit here, just set the variable
    } catch (e) {
      emit(LastMonthAttendanceSummaryError(e.toString()));
    }
  }

  int get getAttendedDays => attendedDays;
  
}
