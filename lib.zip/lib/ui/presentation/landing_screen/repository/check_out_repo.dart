import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:el_race/ui/presentation/signin/data/repository.dart';
import 'package:el_race/utils/api_query.dart';
import 'package:intl/intl.dart';

import '../../../../utils/urll_utils.dart';

UserRepo _userRepo = UserRepo();

DateTime now = DateTime.now();

// Format it as 'YYYY-MM-DD HH:mm:ss'
String formattedDate = DateFormat('yyyy-MM-dd HH:mm:ss').format(now);

ApiQuery _apiQuery = ApiQuery();

class CheckOutRepo {
  Future<Response?> checkOutUser(String lat, String long, int checkInRecordId) async {
    final loginResponse = await _userRepo.getLoginResponse();

    var token = loginResponse!.result!.token!;

    var userResponse = await _userRepo.getLoginResponse();
    var deviceInfo = await _userRepo.getDeviceInfo();
    try {
      var userID = userResponse!.result!.data!.uid.toString();
      Map<String, String> header = {
        "Content-Type": "application/json",
        'Accept': 'application/json',
        "Authorization": "Bearer $token"
      };
      Map<String, dynamic> data = {
        "jsonrpc": "2.0",
        "params": {
          "user_id": int.tryParse(userID.toString()) ?? 0,
          "device_id": deviceInfo,
          "checkout_date_time": formattedDate,
          "check_out_long": long,
          "check_out_lat": lat,
          "check_in_record_id": checkInRecordId,
        }
      };

      log(data.toString());

      Response? response = await _apiQuery.postQuery(
          UrlUtil.checkOutApi, header, data, 'checkout', true);
      log(UrlUtil.checkOutApi);
      log(data.toString());
      log(response.toString());

      return response!;
    } catch (e) {
      log('checkOutUser $e');
    }
    return null;
  }
}
